Japan Trip mobile web app.
Open index.html through a web host, then on iPhone Safari use Share > Add to Home Screen.
Your itinerary, packing list, bookings and expenses are saved locally on the device.
